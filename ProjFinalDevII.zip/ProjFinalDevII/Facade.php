<?php


class Facade
{
    public function render()
    {

        include('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/3View/login.php');
    }
}

$facade = new Facade();
$facade->render();
?>
