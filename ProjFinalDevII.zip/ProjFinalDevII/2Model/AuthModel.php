<?php

require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/Auditoria/AuditLog.php');

require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');
session_start();

class AuthModel {
  private $clientId = '772866045863-mei2cml3kcdqtlmbod3bpcvjonfgs1nn.apps.googleusercontent.com';
  private $clientSecret = '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';
  private $redirectUri = 'http://localhost/ProjFinalDevII/3View/system.html'; //  URI de redirecionamento autorizada 

  private $auditLog;
  public function __construct() {
    $this->auditLog = new AuditLog('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/Auditoria/logFile.txt');
  }

  public function getAuthUrl() {
  
    $this->auditLog->logAction('Login','Iniciando tentativa de login...');

    $client = new Google_Client();
    $client->setClientId($this->clientId);
    $client->setClientSecret($this->clientSecret);
    $client->setRedirectUri($this->redirectUri);
    
    $client->setAccessType('offline');
    $client->setApprovalPrompt('force');

    $scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/userinfo.profile'
    ];
    $client->setScopes($scopes);

    if (isset($_SESSION['access_token'])) {
      $client->setAccessToken($_SESSION['access_token']);

      if ($client->isAccessTokenExpired()) {
        if (isset($_SESSION['refresh_token'])) {
          $refreshToken = $_SESSION['refresh_token'];
          $client->refreshToken($refreshToken);
          $_SESSION['access_token'] = $client->getAccessToken();
        } else {
          return $client->createAuthUrl();
        }
      }


      $service = new Google_Service_Oauth2($client);
      $userInfo = $service->userinfo->get();

      $this->auditLog->logAction('Autenticação','Autenticação realizada');

      return [
        'id' => $userInfo->getId(),
        'name' => $userInfo->getName(),
        'email' => $userInfo->getEmail()
      ];
    } else {
      $this->auditLog->logAction('Erro', 'Token de acesso expirado');
      return $client->createAuthUrl();
    }
  }
}
?>
