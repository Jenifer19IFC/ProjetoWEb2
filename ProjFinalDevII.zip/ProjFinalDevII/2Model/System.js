var map;
var currentLocationLatLng;
var searchHistory = [];

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -34.397, lng: 150.644 },
        zoom: 8
    });

    var input = document.getElementById('search-input');
    var autocomplete = new google.maps.places.Autocomplete(input);

    autocomplete.addListener('place_changed', function() {
        var place = autocomplete.getPlace();
        if (place.geometry) {
            // Centralizar o mapa na localização selecionada
            map.setCenter(place.geometry.location);
            map.setZoom(15);
        }
    });

    // Obter a localização atual do usuário
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;

            // Centralizar o mapa na localização atual do usuário
            currentLocationLatLng = new google.maps.LatLng(lat, lng);
            map.setCenter(currentLocationLatLng);
            map.setZoom(15);

            // Exibir a localização do usuário
            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({ 'location': currentLocationLatLng }, function(results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var addressComponents = results[0].address_components;
                        var formattedAddress = '';

                        for (var i = 0; i < addressComponents.length; i++) {
                            var addressComponent = addressComponents[i];
                            var types = addressComponent.types;

                            if (types.includes('street_number')) {
                                formattedAddress += addressComponent.long_name + ', ';
                            }
                            if (types.includes('route')) {
                                formattedAddress += addressComponent.long_name + ', ';
                            }
                            if (types.includes('sublocality_level_1')) {
                                formattedAddress += addressComponent.long_name + ', ';
                            }
                            if (types.includes('administrative_area_level_2')) {
                                formattedAddress += addressComponent.long_name + ', ';
                            }
                            if (types.includes('administrative_area_level_1')) {
                                formattedAddress += addressComponent.long_name + ', ';
                            }
                            if (types.includes('country')) {
                                formattedAddress += addressComponent.long_name;
                            }
                        }

                        currentLocation = formattedAddress;
                        document.getElementById('current-location').value = currentLocation;
                    }
                }
            });

            // Realizar a busca de locais com a nova localização do usuário
            searchLocations();
        });
    }
}

function searchLocations() {
    var term = document.getElementById('search-term').value;

    var service = new google.maps.places.PlacesService(map);
    service.nearbySearch({
        location: map.getCenter(),
        radius: 5000,
        keyword: term
    }, function(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            var locations = document.getElementById('locations');
            locations.innerHTML = '';

            for (var i = 0; i < results.length; i++) {
                var place = results[i];
                var name = place.name;
                var address = place.vicinity;
                var rating = place.rating;
                var priceLevel = place.price_level;
                var photoUrl = place.photos && place.photos.length > 0 ? place.photos[0].getUrl({ maxWidth: 200, maxHeight: 200 }) : '';

                var placeLocation = place.geometry.location;
                var distance = google.maps.geometry.spherical.computeDistanceBetween(currentLocationLatLng, placeLocation) / 1000;
                distance = Math.round(distance * 100) / 100; // Arredondar para duas casas decimais

                var item = document.createElement('li');
                item.innerHTML = `
                    <div>
                        <strong>${name}</strong><br>
                        Endereço: ${address}<br>
                        Classificação: ${rating} <span class="rating-stars"></span><br>
                        
                        Distância: ${distance.toFixed(2)} km
                    </div>
                    <div>
                        <img src="${photoUrl}" alt="${name}" width="200" height="200">
                    </div>
                    <div>
                        <a href="#" onclick="toggleOpinionBox(${i}); return false;">Deixe sua opinião</a>
                        <div id="opinion-${i}" class="opinion-box" style="display: none;">
                            <textarea id="opinion-text-${i}" placeholder="Deixe sua opinião"></textarea>
                            <button type="button" onclick="saveOpinion(${i})">Salvar Opinião</button>
                        </div>
                    </div>
                    `;

                // Adicionar evento de clique para mostrar o local no mapa
                item.addEventListener('click', function(place) {
                    return function() {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);
                        showPlaceDetails(place);
                    };
                }(place));

                locations.appendChild(item);

                // Adicionar marcador no mapa para o local
                var marker = new google.maps.Marker({
                    position: place.geometry.location,
                    map: map,
                    title: name
                });

                // Adicionar evento de mouseover para mostrar informações ao passar o mouse sobre o marcador
                marker.addListener('mouseover', function(place) {
                    return function() {
                        showPlaceDetails(place);
                    };
                }(place));

                // Adicionar evento de mouseout para limpar as informações ao tirar o mouse do marcador
                marker.addListener('mouseout', function() {
                    clearPlaceDetails();
                });
            }

            // Salvar o histórico de pesquisa
            saveSearchHistory(term);
        } else {
            var locations = document.getElementById('locations');
            locations.innerHTML = '';

            var item = document.createElement('li');
            item.textContent = 'Nenhum local encontrado para o termo digitado.';

            locations.appendChild(item);

            // Salvar o histórico de pesquisa mesmo quando nenhum local é encontrado
            saveSearchHistory(term);
        }
    });
}

function saveSearchHistory(term) {
    if (term !== null && term !== "") {
        var input = document.getElementById('search-input').value;
        var location = term + ' (' + input + ')';
        var currentDate = new Date();
        var formattedDate = currentDate.toLocaleString(); // Obter a data e a hora formatadas

        var searchEntry = {
            term: term,
            location: location,
            date: formattedDate
        };

        searchHistory.push(searchEntry);

        // Atualizar o histórico de pesquisa na tela
        var historyList = document.getElementById('search-history');
        historyList.innerHTML = '';

        for (var i = searchHistory.length - 1; i >= 0; i--) {
            var entry = searchHistory[i];
            var item = document.createElement('li');
            item.innerHTML = `
                <div class="history-item">
                    <strong>${entry.term}</strong><br>
                    Localidade: ${entry.location}<br>
                    Data e Hora: ${entry.date}
                </div>
            `;
            historyList.appendChild(item);
        }
    }
}

$(document).ready(function(){
    initMap();
});