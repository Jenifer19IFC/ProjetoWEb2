<!-- <html lang="pt-br">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Google authentication - Exemplo 1</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap-theme.min.css">
  <style>
    .google-login-img {
      width: 10px;
      height: 10px;
    }
  </style>
</head>
<body>
  <div class="container body-content">
    <div class="box-login">
      <h2>Login</h2>

      <!-- Botão de login do Google -->
      <?php
      require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');

      session_start();

      // Configurações da credencial
      $clientId = '772866045863-mei2cml3kcdqtlmbod3bpcvjonfgs1nn.apps.googleusercontent.com';
      $clientSecret = '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';
      $redirectUri = 'http://localhost/ProjFinalDevII/programa/sistema.php'; // Atualize com sua URI de redirecionamento autorizada

      // Cria o objeto cliente
      $client = new Google_Client();
      $client->setClientId($clientId);
      $client->setClientSecret($clientSecret);
      $client->setRedirectUri($redirectUri);

      // Define os escopos necessários para sua aplicação
      $scopes = [
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile'
      ];
      $client->setScopes($scopes);

      // Verifica se o usuário já está autenticado
      if (isset($_SESSION['access_token'])) {
        $client->setAccessToken($_SESSION['access_token']);

        // Verifica se o token de acesso expirou, se sim, solicita um novo
        if ($client->isAccessTokenExpired()) {
          $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
          $_SESSION['access_token'] = $client->getAccessToken();
        }

        // Faz uma solicitação à API do Google para obter as informações do usuário
        $service = new Google_Service_Oauth2($client);
        $userInfo = $service->userinfo->get();

        // Exibe as informações do usuário
        echo 'ID do usuário: ' . $userInfo->getId() . '<br>';
        echo 'Nome: ' . $userInfo->getName() . '<br>';
        echo 'E-mail: ' . $userInfo->getEmail() . '<br>';
      } else {
        // O usuário não está autenticado, exibe o botão de login do Google
        echo '<a href="' . $client->createAuthUrl() . '" class="btn btn-primary">';
        echo '<img src="C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/img/google.png" alt="Login with Google" class="google-login-img" style="vertical-align: middle; margin-right: 10px;">';
        echo 'Login with Google';
        echo '</a>';
      }
      ?>

      <hr/>
      <a href="javascript:void(0);" onclick="signOut();">Sign out</a>
    </div>
    <hr />
    <footer>
      <p>&copy; Angelo e Jenifer Desenvolvimento Web II. Professor Wesley</p>
    </footer>
  </div>

  <!--JQuery e Bootstrap - Não são obrigatórios para autenticação-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>
</body>
</html> -->
