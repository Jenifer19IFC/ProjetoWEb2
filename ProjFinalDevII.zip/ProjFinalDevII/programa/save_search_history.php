<!-- <?php
// Recupera os dados enviados via POST
$history = $_POST['history'];

// Salva o histórico de pesquisa no Redis
use Predis\Client;

// Conectando ao Redis
$redis = new Client();
$redis->connect('127.0.0.1', 6379);
$redis->lPush('search_history', json_encode($history));

// Retorna uma resposta de sucesso
echo json_encode(['success' => true]); -->