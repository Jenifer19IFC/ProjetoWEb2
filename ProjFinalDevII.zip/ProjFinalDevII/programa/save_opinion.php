<!-- <?php
// Recupera os dados enviados via POST
$opinion = $_POST['opinion'];
$index = $_POST['index'];

// Salva a opinião no Redis
use Predis\Client;

// Conectando ao Redis
$redis = new Client();
$redis->connect('127.0.0.1', 6379);
$redis->hSet('opinions', $index, $opinion);

// Retorna uma resposta de sucesso
echo json_encode(['success' => true]); -->