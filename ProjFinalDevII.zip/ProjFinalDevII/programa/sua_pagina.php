<!-- <?php

require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');

try {
    // Conexão com o Redis
    $redis = new Predis\Client();
    $redis->connect('localhost');

    // Verificar se a conexão foi estabelecida com sucesso
    if ($redis->isConnected()) {
        echo 'Conexão com o Redis estabelecida com sucesso.';
    } else {
        echo 'Falha ao conectar-se ao Redis.';
    }
} catch (Exception $e) {
    echo 'Erro ao conectar-se ao Redis: ' . $e->getMessage();
}

// Verificar se o campo de pesquisa não está vazio
if (!empty($_POST['term'])) {
    $term = $_POST['term'];

    // Insere o termo de pesquisa no Redis
    $redis->rpush('search_history', $term);

    // Verifica se a chave 'search_history' é uma lista
    if ($redis->type('search_history') === 'list') {
        // Obtém todos os elementos da lista 'search_history' no Redis
        $searchHistory = $redis->lrange('search_history', 0, -1);

        // Imprime os dados salvos
        echo "Dados salvos no Redis:<br>";
        foreach ($searchHistory as $searchTerm) {
            echo $searchTerm . "<br>";
        }

        // Retorna uma resposta de sucesso para o JavaScript
        http_response_code(200);
        echo 'Dados de pesquisa salvos no Redis com sucesso.';
    } else {
        // Lida com o caso em que a chave 'search_history' não é uma lista
        http_response_code(400);
        echo 'A chave "search_history" não é uma lista válida no Redis.';
    }
} else {
    // Lida com o caso em que o campo de pesquisa está vazio
    http_response_code(400);
    echo 'Campo de pesquisa vazio.';
}

?> -->
