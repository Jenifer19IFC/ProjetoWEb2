<!-- <!DOCTYPE html>
<html>
<head>
    <title>Histórico de Pesquisa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        h2, h4, p {
            text-align: center;
        }
        ul {
            list-style-type: none;
            padding-left: 0;
            text-align: center;
        }
        .history-item {
            background-color: #f8f9fa;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Histórico de Pesquisa</h2>
        <div class="card">
            <div class="card-body">
                <?php

                require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');

                // Recuperar o histórico de pesquisa da URL
                if (isset($_GET['history'])) {
                    $searchHistoryJson = $_GET['history'];

                    // Converter o JSON em um array PHP
                    $searchHistory = json_decode($searchHistoryJson, true);

                    // Reverter a ordem dos elementos do array
                    $searchHistory = array_reverse($searchHistory);

                    // Salvar a lista no Redis
                    $redis = new Predis\Client();
                    $redis->connect('localhost', 6379); // Configurar host e porta do servidor Redis

                    // Verificar se a conexão foi estabelecida com sucesso
                    if ($redis->isConnected()) {
                        $redis->set('searchHistory', json_encode($searchHistory));
                    } else {
                        echo '<p>Falha ao conectar-se ao servidor Redis.</p>';
                    }

                    // Exibir o conteúdo atual do banco de dados Redis
                    $searchHistory = $redis->get('searchHistory');
                    if ($searchHistory) {
                        $searchHistoryArray = json_decode($searchHistory, true);
                        echo '<ul>';
                        foreach ($searchHistoryArray as $entry) {
                            $term = $entry['term'];
                            $location = $entry['location'];
                            $date = $entry['date'];
                            echo '<li class="history-item">';
                            echo '<strong>' . $term . '</strong><br>';
                            echo 'Pesquisa: ' . $location . '<br>';
                            echo 'Data e Hora: ' . $date . '<br>';
                            echo '</li>';
                        }
                        echo '</ul>';
                    } else {
                        echo '<p>Nenhum histórico de pesquisa encontrado no banco de dados Redis.</p>';
                    }
                } else {
                    echo '<p>Nenhum histórico de pesquisa encontrado.</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html> -->
