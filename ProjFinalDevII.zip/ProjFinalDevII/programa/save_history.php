<!-- 
<?php
$redis = new Predis\Client();
$redis->connect('127.0.0.1', 6379);

if (isset($_POST['searchHistory'])) {
    $searchHistory = json_decode($_POST['searchHistory']);
    $redis->set('search_history', json_encode($searchHistory));
    echo 'Search history saved successfully.';
}
?> -->
