<!-- <?php
    if (isset($_GET['code'])) {
        $code = $_GET['code'];
        echo 'Código de autorização: ' . $code;
    } else {
        echo 'Código de autorização não encontrado.';
    }
?> -->
