<!DOCTYPE html>
<html>
<head>
    <title>Histórico de Pesquisa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        h2, h4, p {
            text-align: center;
        }
        ul {
            list-style-type: none;
            padding-left: 0;
            text-align: center;
        }
        .history-item {
            background-color: #f8f9fa;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Histórico de Pesquisa</h2>
        <div class="card">
            <div class="card-body">
                <?php if ($searchHistoryArray && is_array($searchHistoryArray)): ?>
                    <ul>
                        <?php foreach ($searchHistoryArray as $entry): ?>
                            <li class="history-item">
                                <strong><?php echo $entry['term']; ?></strong><br>
                                Pesquisa: <?php echo $entry['location']; ?><br>
                                Data e Hora: <?php echo $entry['date']; ?><br>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>Nenhum histórico de pesquisa encontrado no banco de dados Redis.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
