<?php
require_once('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/2Model/AuthModel.php');

$authModel = new AuthModel();
$authUrl = $authModel->getAuthUrl();
?>

<html lang="pt-br">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Google authentication - Exemplo 1</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap-theme.min.css">
  <style>
    .google-login-img {
      width: 35px; 
      height: 35px; 
    }

    .login-notice {
      background-color: #f2f2f2;
      border: 2px solid #e0e0e0;
      padding: 20px;
      text-align: center;
      border-radius: 10px;
      margin-bottom: 30px;
      margin-top: 50px; 
    }

    .company-name {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .company-description {
      font-size: 16px;
    }
  </style>
</head>
<body>
  <div class="container body-content">
    <div class="box-login">

      <!-- Aviso de login necessário -->
      <?php
      if (is_array($authUrl)) {
        echo 'ID do usuário: ' . $authUrl['id'] . '<br>';
        echo 'Nome: ' . $authUrl['name'] . '<br>';
        echo 'E-mail: ' . $authUrl['email'] . '<br>';
      } else {
        echo '<div class="login-notice">';
        echo '<h3 class="company-name">Bem-vindo</h3>';
        echo '<p class="company-description">Faça o login para acessar nosso localizador e aproveitar todos os recursos exclusivos.</p>';
        echo '<a href="' . $authUrl . '" class="btn btn-primary">';
        echo '<img src="/ProjFinalDevII/img/google.png" alt="Login with Google" class="google-login-img" style="vertical-align: middle; margin-right: 10px;">';
        echo 'Login with Google';
        echo '</a>';
        echo '</div>';
      }
      ?>

      <hr/>
      <a href="javascript:void(0);" onclick="signOut();">Sign out</a>
    </div>
    <hr />
    <footer>
      <p>&copy; Angelo e Jenifer Desenvolvimento Web II. Professor Wesley</p>
    </footer>
  </div>

  <!--JQuery e Bootstrap - Não são obrigatórios para autenticação-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>
</body>
</html>
