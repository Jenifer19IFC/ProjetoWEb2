<?php

require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');
require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/4Config/RedisConexao.php');
require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/Auditoria/AuditLog.php');

class SearchHistory
{
    private $redisConnection;

    private $auditLog;

    public function __construct()
    {
        $this->redisConnection = new RedisConnection();
        $this->auditLog = new AuditLog('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/Auditoria/logFile.txt');
    }

    public function processSearchHistory()
    {
        // Recuperar o histórico de pesquisa da URL
        if (isset($_GET['history'])) {
            $searchHistoryJson = $_GET['history'];

            // Converter o JSON em um array PHP
            $searchHistory = json_decode($searchHistoryJson, true);

            // Reverter a ordem dos elementos do array
            $searchHistory = array_reverse($searchHistory);

            // Salvar a lista no Redis
            $redis = $this->redisConnection->getRedis();

            // Verificar a conexão foi estabelecida
            if ($this->redisConnection->isConnected()) {
                $redis->set('searchHistory', json_encode($searchHistory));
                $this->auditLog->logAction('Dados de pesquisa salvos',$searchHistory);
            } else {
                echo '<p>Falha ao conectar-se ao servidor Redis.</p>';
                $this->auditLog->logAction('Redis','Falha de conexão com Redis');
            }

            // Exibir o conteúdo atual do banco de dados Redis
            $searchHistory = $redis->get('searchHistory');
            if ($searchHistory) {
                $searchHistoryArray = json_decode($searchHistory, true);
                include('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/3View/search_history_view.php'); 
            } else {
                echo '<p>Nenhum histórico de pesquisa encontrado no banco de dados Redis.</p>';
                $this->auditLog->logAction('Sem histórico de pesquisa','Não há dados no banco de dados Redis');
            }
        } else {
            echo '<p>Nenhum histórico de pesquisa encontrado.</p>';
            $this->auditLog->logAction('Pesquisa','Dados não foram encontrados');
        }
    }
}
?>

<?php
// Instanciar a classe e chamar o método para processar o histórico de pesquisa
$searchHistoryObj = new SearchHistory();
$searchHistoryObj->processSearchHistory();
?>
