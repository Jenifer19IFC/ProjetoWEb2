<?php

class AuditLog
{
    private $logFilePath;

    public function __construct($logFilePath)
    {
        $this->logFilePath = $logFilePath;
    }

    public function logAction($action, $details = null)
    {
        date_default_timezone_set('America/Sao_Paulo');
        $data = date('d/m/Y H:i:s');
        $logEntry = "{$data} - Ação: {$action}";

        if ($details !== null) {
            $formattedDetails = $this->formatDetails($details);
            $logEntry .= ", Detalhes: {$formattedDetails}";
        }

        $logEntry .= PHP_EOL;

        // Adiciona a entrada de log ao arquivo
        file_put_contents($this->logFilePath, $logEntry, FILE_APPEND);
    }

    private function formatDetails($details)
    {
        if (is_array($details)) {
            $formattedDetails = '';
            foreach ($details as $key => $value) {
                if (is_array($value)) {
                    $formattedValue = implode(' -> ', $value);
                    $formattedDetails .= "({$key}) {$formattedValue} -- ";
                } else {
                    $formattedDetails .= "({$key}): {$value} -- ";
                }
            }
            $formattedDetails = rtrim($formattedDetails, ' , ');
            return $formattedDetails;
        } else {
            return $details;
        }
    }
}



?>