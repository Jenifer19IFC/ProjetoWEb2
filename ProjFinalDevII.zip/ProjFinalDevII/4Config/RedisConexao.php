<?php

require('C:/Users/Jenifer/Desktop/XAMPP/htdocs/ProjFinalDevII/vendor/autoload.php');

class RedisConnection
{
    private $redis;

    public function __construct()
    {
        $this->redis = new Predis\Client();
        $this->redis->connect('localhost', 6379); // Configurar host e porta do servidor Redis
    }

    public function getRedis()
    {
        return $this->redis;
    }

    public function isConnected()
    {
        return $this->redis->isConnected();
    }
}
?>
